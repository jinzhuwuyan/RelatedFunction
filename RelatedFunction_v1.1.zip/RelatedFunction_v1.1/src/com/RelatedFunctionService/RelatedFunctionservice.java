package com.RelatedFunctionService;

import com.IRelatedFunction.IBasicFunction;
import com.IRelatedFunction.IPrimary_RelationFuntion;
import com.IRelatedFunction.ISimple_RelationFunction;
import com.SubRelatedFunction.*;

import jadex.bridge.service.annotation.Service;
import jadex.bridge.service.annotation.ServiceStart;
import jadex.commons.future.IFuture;

@Service
public class RelatedFunctionservice implements IBasicFunction,IPrimary_RelationFuntion,ISimple_RelationFunction{

	/**
	 *  Init the service.
	 */
	@ServiceStart
	public IFuture<Void> startService()
	{
		System.out.println("YES");
		return null;
	}

	@Override
	public double cal_locationvalue(double x, double a, double b, double c,
			double d) {
		// TODO Auto-generated method stub
		return new BasicFunction().cal_locationvalue(x, a, b, c, d);
	}

	@Override
	public double cal_square(double x, double a, double b) {
		// TODO Auto-generated method stub
		return new BasicFunction().cal_square(x, a, b);
	}

	@Override
	public double cal_square(double x, double x0, double a, double b) {
		// TODO Auto-generated method stub
		return new BasicFunction().cal_square(x, x0, a, b);
	}

	@Override
	public double Simple_RelationFunction(double x, String a, String b, double M) {
		// TODO Auto-generated method stub
		return new Simple_RelationFunction().Simple_RelationFunction(x, a, b, M);
	}
	
	@Override
	public double getSimpleDependentFunValue_Limited(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		
		return new Simple_RelationFunction().getSimpleDependentFunValue_Limited(x, a, b, M);
	}

	@Override
	public double getSimpleDependentFunValue_Limitless(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		return  new Simple_RelationFunction().getSimpleDependentFunValue_Limitless(x, a, b, M);
	}

	@Override
	public double getElementaryDependentFunValue_Mid(double x, double a0,
			double b0, double a, double b, double c, double d, double x0) {
		// TODO Auto-generated method stub
		return new Primary_RelationFuntion().getElementaryDependentFunValue_Mid(x, a0, b0, a, b, c, d, x0);
	}

	@Override
	public double getElementaryDependentFunValue_NotMid(double x, double a0,
			double b0, double a, double b, double c, double d, double x0) {
		// TODO Auto-generated method stub
		return new Primary_RelationFuntion().getElementaryDependentFunValue_NotMid(x0, a0, b0, a, b, c, d, x);
	}

	@Override
	public double Primary_RelationFuntion(double x0, double a0, double b0,
			double a, double b, double c, double d, double x) {
		// TODO Auto-generated method stub
		return new Primary_RelationFuntion().Primary_RelationFuntion(x0, a0, b0, a, b, c, d, x);
	}
	
	
	
	

	
}
