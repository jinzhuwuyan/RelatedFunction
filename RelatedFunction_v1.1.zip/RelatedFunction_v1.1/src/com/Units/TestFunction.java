package com.Units;
import org.junit.Test;

import com.RelatedFunctionService.*;


public class TestFunction {
	public double cal_locationvalue(double x, double a, double b, double c,
			double d) {
		// TODO Auto-generated method stub
		return cal_locationvalue(x, a, b, c, d);
	}

	
	public double cal_square(double x, double a, double b) {
		// TODO Auto-generated method stub
		return cal_square(x, a, b);
	}

	
	public double cal_square(double x, double x0, double a, double b) {
		// TODO Auto-generated method stub
		return cal_square(x, x0, a, b);
	}

	
	public double Simple_RelationFunction(double x, String a, String b, double M) {
		// TODO Auto-generated method stub
		return Simple_RelationFunction(x, a, b, M);
	}
	
	
	public double getSimpleDependentFunValue_Limited(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		
		return getSimpleDependentFunValue_Limited(x, a, b, M);
	}

	
	public double getSimpleDependentFunValue_Limitless(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		return  getSimpleDependentFunValue_Limitless(x, a, b, M);
	}

	
	public double getElementaryDependentFunValue_Mid(double x, double a0,
			double b0, double a, double b, double c, double d, double x0) {
		// TODO Auto-generated method stub
		return getElementaryDependentFunValue_Mid(x, a0, b0, a, b, c, d, x0);
	}

	public double getElementaryDependentFunValue_NotMid(double x, double a0,
			double b0, double a, double b, double c, double d, double x0) {
		// TODO Auto-generated method stub
		return getElementaryDependentFunValue_NotMid(x0, a0, b0, a, b, c, d, x);
	}

	public double Primary_RelationFuntion(double x, double a0, double b0,
			double a, double b, double c, double d, double x0) {
		// TODO Auto-generated method stub
		return Primary_RelationFuntion(x, a0, b0, a, b, c, d, x0);
	}

		
		

		
	
//	@Test
////测试简单关联函数
//	public void test() {
////		System.out.println("SimpleDependentFunValue");
////		System.out.println(this.getSimpleDependentFunValue_Limited(5, "1", "6", 0));
////		System.out.println(this.getSimpleDependentFunValue_Limitless(1, "-inf", "6", 7));
//	
//	}
//	@Test
//	//测试基本函数
//	public void test(){
//		System.out.println("BasicFunValue");
//		System.out.println(this.cal_square(-11, 1, 9));
//		System.out.println(this.cal_square(-5, 5, -2, 6));
//		System.out.println(this.cal_locationvalue(6, 3, 5, 1, 9));
//	}
	@Test
	//测试初等关联函数
	public void test(){
		System.out.println("ElementaryDependentFunValue");
		System.out.println(this.Primary_RelationFuntion(8, 0, 0, 3, 7, 3, 11, 5));
	}

}
