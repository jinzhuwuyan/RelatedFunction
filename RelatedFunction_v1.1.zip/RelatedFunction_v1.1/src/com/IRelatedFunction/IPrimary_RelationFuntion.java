package com.IRelatedFunction;
/**
 * (a0,b0) -- 满意区间
 * (a ,b ) -- 可接受区间
 * (c ,d ) -- 不可接收到可接受的过渡区间
 * (-inf ,c ),(d , inf ) -- 完全不可接受区间
 * @author shamaowei
 *
 */
public interface IPrimary_RelationFuntion {
	/**
	 * 求初等关联函数值
	 * @param x0 自变量
	 * @param a0 完全接收区间左侧
	 * @param b0 完全接收区间右侧
	 * @param a 可接受区间左侧
	 * @param b 可接受区间右侧
	 * @param c 可转化区间左侧
	 * @param d 可转化区间右侧
	 * @return double
	 * 
	 */
	public double Primary_RelationFuntion(double x,double a0, double b0,double a, double b, double c, double d,double x0);
	/**
	 * 求最优值在(a0,b0)中点时初等关联函数值
	 * @param x0 自变量
	 * @param a0 完全接收区间左侧
	 * @param b0 完全接收区间右侧
	 * @param a 可接受区间左侧
	 * @param b 可接受区间右侧
	 * @param c 可转化区间左侧
	 * @param d 可转化区间右侧
	 * @return  double
	 * 
	 */
	public double getElementaryDependentFunValue_Mid(double x,double a0, double b0,double a, double b, double c, double d,double x0);
	/**
	 * 求最优值不在(a0,b0)中点时初等关联函数值
	 * @param x 自变量
	 * @param a0 满意区间左侧
	 * @param b0 满意区间右侧
	 * @param a  可接受区间左侧
	 * @param b  可接受区间右侧
	 * @param c  过渡区间左侧
	 * @param d  过渡区间右侧
	 * @param x0  最优值
	 * @return   double
	 */
	public double getElementaryDependentFunValue_NotMid(double x,double a0, double b0,double a, double b, double c, double d,double x0);
}
