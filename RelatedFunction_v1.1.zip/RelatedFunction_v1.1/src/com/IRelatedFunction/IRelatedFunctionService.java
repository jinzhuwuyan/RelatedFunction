package com.IRelatedFunction;

public interface IRelatedFunctionService {
	public double cal_locationvalue(double x, double a,double b,double c, double d);
	public double cal_square(double x, double a, double b);
	public double cal_square(double x, double x0, double a, double b);
	public double Primary_RelationFuntion(double x,double a0, double b0,double a, double b, double c, double d,double x0 );
	public double getElementaryDependentFunValue_Mid(double x,double a0, double b0,double a, double b, double c, double d,double x0);
	public double getElementaryDependentFunValue_NotMid(double x,double a0, double b0,double a, double b, double c, double d,double x0);
	public double Simple_RelationFunction(double x, String a,String b, double M);
	public double getSimpleDependentFunValue_Limited(double x,String a,String b,double M);
	public double getSimpleDependentFunValue_Limitless(double x,String a,String b,double M);
}
