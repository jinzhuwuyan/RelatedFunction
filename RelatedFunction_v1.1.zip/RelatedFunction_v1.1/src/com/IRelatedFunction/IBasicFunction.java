package com.IRelatedFunction;

public interface IBasicFunction {
	/**
	 * 计算位值
	 * @param x 自变量
	 * @param a 完全接收区间左侧
	 * @param b 完全接收区间右侧
	 * @param c 可接受区间左侧
	 * @param d 可接收区间右侧
	 * @return double
	 */
	public double cal_locationvalue(double x, double a,double b,double c, double d);
	/**
	 * 计算距(中距)--最值点为(a,b)的中点
	 * @param x 自变量
	 * @param a 范围左侧
	 * @param b 范围右侧
	 * @return double
	 */
	public double cal_square(double x, double a, double b);
	/**
	 * 计算侧距
	 * @param x 自变量
	 * @param x0 最优值点
	 * @param a 范围左侧
	 * @param b 范围右侧
	 * @return double
	 */
	public double cal_square(double x, double x0, double a, double b);
}
