package com.IRelatedFunction;

public interface ISimple_RelationFunction {
	/**
	 * 计算简单关联函数值
	 * @param x 自变量
	 * @param a 任意区间的左边(String)
	 * @param b 任意区间的右边(String)
	 * @param M 最右值
	 * @return double
	 */
 public double Simple_RelationFunction(double x, String a,String b, double M);
 /**
  * 计算有限区间的简单关联函数
  * @param x 自变量
  * @param a 有限区间的左边(String)
  * @param b 有限区间的右边(String)
  * @param M 最优值
  * @return double
  * @throws none
  */
 public double getSimpleDependentFunValue_Limited(double x,String a,String b,double M);
 /**
  * 计算非有限区间的简单关联函数
  * -inf（左无穷大）或inf（右无穷大）
  * @param x 自变量
  * @param a 区间的左边("-inf"或"常数")(String)
  * @param b 区间的右边("inf"或"常数")(String)
  * @param M 最优值
  * @return double
  * @throws 如果a取"inf"或b取"-inf"的话，返回0.00
  */
 public double getSimpleDependentFunValue_Limitless(double x,String a,String b,double M);
}
