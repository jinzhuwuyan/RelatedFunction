package com.SubRelatedFunction;

import java.math.BigDecimal;

import com.IRelatedFunction.IBasicFunction;

public class BasicFunction implements IBasicFunction{

	@Override
	public double cal_square(double x, double a, double b) {
		
			// TODO Auto-generated method stub
			double t = (a + b)/2.0;
			BigDecimal aa = new BigDecimal(t);
			BigDecimal bb = new BigDecimal(x);

			if(bb.compareTo(aa) <= 0)//t > x
			{
				System.out.println(x +" <= "+ t);
				return a-x;
			
			}
			else
				return x-b;
		}
	@Override
	public double cal_square(double x, double x0, double a, double b){
		double result = 0.00;
		BigDecimal a_ = new BigDecimal(a);
		BigDecimal b_ = new BigDecimal(b);
		BigDecimal a_b = new BigDecimal((a+b)/2.0);
		BigDecimal x_ = new BigDecimal(x);
		BigDecimal x0_ = new BigDecimal(x0);

		if(x0_.compareTo(a_b) < 0 && x0_.compareTo(a_) > 0)//left
			if(x_.compareTo(a_) <= 0)
			{
				result = a - x;
			}else if(x_.compareTo(x0_) >= 0)
			{
				result = x - b;
			}else result = (b - x0) / (a - x0) * (x -a);
		else {					 //right
			if(x_.compareTo(x0_) <= 0)
			{
				result = a - x;
			}else if(x_.compareTo(b_) >= 0)
			{
				result = x - b;
			}else result = (b - x0) / (a - x0) * (b - x);
		}
		
		return result;
	}

	@Override
	public double cal_locationvalue(double x, double a,double b,double c, double d) 
	{
		double sum;
		sum = new BasicFunction().cal_square(x, c, d) - new BasicFunction().cal_square(x, a, b);
		return sum;
	}

	
	
}
