package com.SubRelatedFunction;

import com.IRelatedFunction.ISimple_RelationFunction;

public class Simple_RelationFunction implements ISimple_RelationFunction{
	public double Simple_RelationFunction(double x, String a,String b, double M){
		double result = 0.00;
		if(!a.equals("-inf") && !b.equals("inf"))
		{
			result = getSimpleDependentFunValue_Limited(x, a, b, M);
		}else result = getSimpleDependentFunValue_Limitless(x, a, b, M);
		return result;
	}

	@Override
	public double getSimpleDependentFunValue_Limited(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		double result = 0.00;
		
		double aa = Double.valueOf(a);
		double bb = Double.valueOf(b);
		if(aa > bb)
			return -0.000000000000001;
		else if( M < aa || M > bb ) //检测最优值是否在区间内
			return -0.000000000000001;
		
		
		if(M > aa && M < bb)
			if(x <= M)
				result = (x - aa) / (M - aa);
			else result = (bb - x) / (bb - M);
		else if(M == aa)
				if(x < aa)
					result = (x - aa) / (bb - aa);
				else result = (bb - x) / (bb - aa);
		else if(M == bb)
				if(x <= bb)
					result = (x - aa) / (bb - aa);
				else result = (bb - x) / (bb - aa);
		
		return result;
	}

	
	public double getSimpleDependentFunValue_Limitless(double x, String a,
			String b, double M) {
		// TODO Auto-generated method stub
		double result = 0.00;
		
		
		if(a.equals("inf") || b.equals("-inf"))//检测范围的左右无穷是否错误
			return -0.000000000000001;
		
		if(a.equals("-inf") && !b.equals("inf"))
		{
			double bb = Double.valueOf(b);
			if( M > bb ) //检测最优值是否在区间内
				return -0.000000000000001;
			if(x <= M)
				 result = M / (2 * M - x);
			else result = (x - bb) / (M - bb);
		}
		else if(!a.equals("-inf") && b.equals("inf"))
		{
				double aa = Double.valueOf(a);
				if( M < aa ) //检测最优值是否在区间内
					return -0.000000000000001;
				if(x <= M)
				result = (x - aa) / (M - aa);
				else result = M / (2 * x - M);
		}else if(a.equals("-inf") && b.equals("inf"))	
		{
			 if(x <= M)
				 result = 1 / (1 + M - x);
			 else
				 result = 1 / (x + 1 - M);
		}

		
		return result;
	}
//	public  void main(String[] args) {
//		System.out.println(this.getSimpleDependentFunValue_Limited(3, "1", "6", 5));
//
//	}
}
