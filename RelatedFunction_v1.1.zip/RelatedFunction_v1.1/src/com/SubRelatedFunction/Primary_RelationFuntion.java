package com.SubRelatedFunction;
import java.math.BigDecimal;

import com.IRelatedFunction.IPrimary_RelationFuntion;


/***
 * x0->(a0,b0),x->(a,b),∧x->(c,d)
 * x0为标准唯一确定是正确的范围，x为包含x0还包含了可以忍受的范围，∧x为除了完全不可能转换为正确的方位外的其他范围
 * */
public class Primary_RelationFuntion implements IPrimary_RelationFuntion{

@Override
public double Primary_RelationFuntion(double x,double a0, double b0,double a, double b, double c, double d,double x0 ){
	double RelationFunValue = 0.0;
	double mid =(a0+b0) /2;
	if(x0 == mid){
		System.out.println("进入了中点");
		RelationFunValue = getElementaryDependentFunValue_Mid(x0,a0,b0,a,b,c,d,x);
	
	}
	else 
		{
		System.out.println("进入了非中点");	
		RelationFunValue = getElementaryDependentFunValue_NotMid(x0,a0, b0,a, b, c, d,x);
		}
	return RelationFunValue;
}



//public double cal_locationvalue(double x, double a,double b,double c, double d)
/**
 * 
 */
public double getElementaryDependentFunValue_Mid(double x, double a0,
		double b0, double a, double b, double c, double d, double x0) {
	// TODO Auto-generated method stub
	double result = 0;
	
	double D_x_a0b0_ab = new BasicFunction().cal_locationvalue(x,a0,b0,a,b);
	double D_x_ab_cd = new BasicFunction().cal_locationvalue(x,a,b,c,d);
	double p_x_ab = new BasicFunction().cal_square(x, a, b);
	
	
	BigDecimal x_ = new BigDecimal(x);
	BigDecimal a_ = new BigDecimal(a);
	BigDecimal b_ = new BigDecimal(b);
	BigDecimal a0_ = new BigDecimal(a0);
	BigDecimal b0_ = new BigDecimal(b0);
	BigDecimal c_ = new BigDecimal(c);
	BigDecimal d_ = new BigDecimal(d);
	BigDecimal aa = new BigDecimal(D_x_a0b0_ab);
	BigDecimal bb = new BigDecimal(D_x_ab_cd);
	BigDecimal zero = new BigDecimal(0.00);
	if(aa.compareTo(zero) != 0 && x_.compareTo(a_) >= 0 && x_.compareTo(b_) <= 0)
	{
		result = Math.abs(p_x_ab / D_x_a0b0_ab);
	}else if(aa.compareTo(zero) == 0 && x_.compareTo(a0_) >= 0 && x_.compareTo(b0_) <= 0)
	{
		result = -new BasicFunction().cal_square(x, a0, b0) + 1;
	}else if(aa.compareTo(zero) == 0  && x_.compareTo(a_) >= 0 && x_.compareTo(a0_) <= 0 && x_.compareTo(b0_) >= 0 && x_.compareTo(b_) <= 0)
	{
		result = 0.00;
	}else if(bb.compareTo(zero) != 0  && ( x_.compareTo(a_) <= 0 || x_.compareTo(b_) >= 0 ))
	{
		result = p_x_ab / D_x_ab_cd;
	}else if(bb.compareTo(zero) == 0 && ( x_.compareTo(a_) <= 0 || x_.compareTo(b_) >= 0 ))
	{
		result = -new BasicFunction().cal_square(x, c, d) - 1.00;
	}
	return result;
}

@Override
public double getElementaryDependentFunValue_NotMid(double x, double a0,
		double b0, double a, double b, double c, double d, double x0) {
	// TODO Auto-generated method stub
	double result = 0;
	double D_x_a0b0_ab = new BasicFunction().cal_locationvalue(x,a0,b0,a,b);
	double D_x_ab_cd = new BasicFunction().cal_locationvalue(x,a,b,c,d);
	double p_x_x0_ab = new BasicFunction().cal_square(x, x0, a, b);
	
	if(D_x_a0b0_ab != 0.00 && x>=a && x<= b)
	{
		result = p_x_x0_ab / D_x_a0b0_ab;
	}else if(D_x_a0b0_ab == 0.00 && x>=a0 && x<= b0)
	{
		result = -new BasicFunction().cal_square(x, x0, a0, b0) + 1;
	}else if(D_x_a0b0_ab == 0.00 && x>=a && x<= a0 && x>=b0 && x<= b)
	{
		result = 0.00;
	}else if(D_x_ab_cd != 0.00 && x>=c && x<= a && x>=b && x<= d)
	{
		result = p_x_x0_ab / D_x_ab_cd;
	}else if(D_x_ab_cd == 0.00 && x>=c && x<= a && x>=b && x<= d)
	{
		result = -new BasicFunction().cal_square(x, x0, c, d) - 1.00;
	}
	return result;
}
}
